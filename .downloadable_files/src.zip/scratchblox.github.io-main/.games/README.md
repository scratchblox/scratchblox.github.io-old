# Welcome to the ScratchBlox Game Library!

## For Collabrators and Users Wishing to Submit games
### What files go here?
Any .HTML file may be added. However, before you upload the file, please submit a Game Request in the Game requests section in "discussions."
Make sure your game meets the requirements provided in the pinned topic. Then, create a new thread within the section with your completed form.
If a Leader or Moderator Approves, your game will be added to the games folder (as a HTML) with a few changes, such as a button to go back to the games menu.
Your game may not apppear in the Website's game menu until up to 48 Hours after approval.
