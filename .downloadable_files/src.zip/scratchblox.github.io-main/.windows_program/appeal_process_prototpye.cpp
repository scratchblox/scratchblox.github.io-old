//Code made by @UltraCube100 (Scratch: @minecraftprox101)
//If this code appears in the Scratchblox github repo, this code may and will be licensed under the BSD 3-Clause "New" or "Revised" license.
//Otherwise, it is copyrighted by @UltraCube100 (Scratch stated at line 1) with All Rights Reserved.
//This is a Prototpye, do not use, this is just a concept
#include <cstdlib>
#include <cstdio>
#include <iostream>
//#include "window.h"
//#include <window> or is it #include <windows> or #include <window.h> or  is it #include <windows.h>
//Insert more libraries if I forgot some libraries.
using namespace std;
//insert windows programming code
int main(int nNumberofArgs, char* pszArgs[])
{
 int username;
 cout << "Enter your Username" ;
 cin >> Username ;
 
 int reason;
 cout << "Enter the reason why you want to be unbanned" ;
 cin >> reason ;
 
 int argeement;
 cout << "Do you argee to the ScratchBlox Rules? (y/n)" ;
 cin >> argeement ;
  
 //Ok, So this doesn't end?
 // Insert Cloud Programming
}
